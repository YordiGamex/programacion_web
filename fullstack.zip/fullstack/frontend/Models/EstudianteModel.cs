namespace frontend.Models
{
    public class EstudianteModel
    {
        public int codigo {get;set;}
        public string? tipodocumento {get;set;}
        public string? documento {get;set;}
        public string? nombres {get;set;}
        public string? apellidos {get;set;}
        public string? fechanacimiento {get;set;} 
        public string? sexo {get;set;}
        public Boolean activo {get;set;}
    }
}