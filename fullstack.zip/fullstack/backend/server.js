const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
const estudiante = require('./controlador/estudiante.controlador');
app.use('/api/v1/', estudiante);
app.listen(3000, ()=>{
  console.log('Servidor corriendo en el puerto 3000');
});