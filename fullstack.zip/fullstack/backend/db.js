const db = require('mysql2/promise')
const conectar = db.createPool({
    host:'localhost',
    user: 'root',
    password: 'root',
    database: 'dbprueba'
});
module.exports = conectar
