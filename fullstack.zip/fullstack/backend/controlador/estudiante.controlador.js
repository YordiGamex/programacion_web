const express = require ('express');
http = express.Router();
const estudiante = require ('../servicios/estudiante.servicios')
http.get ('/estudiantes', async (req, res) => {
    const estudiantes = await estudiante.listarEst();
    res.send (estudiantes);
})
http.post('/registrar', async (req, res) => {
    const registrar = await estudiante.CrearEstudiante(req.body);
    res.send (registrar);  
})
http.get('/:documento', async(req,res) => {
    const estudianteEncontrado = await estudiante.BuscarEstudiante(req.params.documento)
    if(estudianteEncontrado == undefined){
        res.status(404).json('No existe estudiante con este documento:' + req.params.documento)
    } else {
        res.send(estudianteEncontrado)
    }
})

module.exports = http;