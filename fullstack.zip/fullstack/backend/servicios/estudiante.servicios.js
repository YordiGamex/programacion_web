const db = require ('../db')

module.exports.CrearEstudiante = async (estudiante) => {
    const sql = "INSERT INTO dbprueba.tblestudiante "+
" VALUES(null, ?, ?, ?, ?, ?, ?, ?);  ";
const [resultado] = await db.execute (sql,[estudiante.tipodocumento, estudiante.documento, estudiante.nombres, 
    estudiante.apellidos, estudiante.fechanacimiento, estudiante.sexo, estudiante.activo]);
return resultado.insertId
};
module.exports.listarEst = async () => {
    const [estudiantes] = await db.query ("select * from tblestudiante");
    return estudiantes;
}
module.exports.insertar = async (insertar) => {
    const sql = "INSERT INTO dbprueba.insertar "+
" VALUES(null, ?);  ";
const [resultado] = await db.execute (sql,[insertar.nombre]);
return resultado.insertId
};
module.exports.listar = async () => {
    const [estudiantes] = await db.query ("select * from insertar");
    return estudiantes;
}

module.exports.BuscarEstudiante = async (documento) => {
    const [estudiantes] = await db.query(`select * from tblestudiante where documento = ${documento}`)
    return estudiantes;
}